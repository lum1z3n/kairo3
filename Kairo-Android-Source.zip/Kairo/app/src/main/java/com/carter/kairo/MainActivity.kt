package com.carter.kairo

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import java.net.URLDecoder

private val Ink = Color(0xFF09090B)
private val Panel = Color(0xFF171316)
private val Crimson = Color(0xFFE02B45)
private val Muted = Color(0xFFB7A8AD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KairoApp() }
    }
}

data class Anime(val title: String, val genre: String, val description: String, val episodes: List<Episode>)
data class Episode(val title: String, val url: String)

private val catalog = listOf(
    Anime(
        "Crimson Horizon", "Action • Fantasy",
        "A sample title for exploring the Kairo interface. Replace this sample with metadata from a licensed catalog.",
        listOf(Episode("Episode 01", ""), Episode("Episode 02", ""), Episode("Episode 03", ""))
    ),
    Anime(
        "Moonlit Archive", "Mystery • Drama",
        "A second sample entry. Connect an authorized catalog API to populate real anime and episode information.",
        listOf(Episode("Episode 01", ""), Episode("Episode 02", ""))
    ),
    Anime(
        "Starlight Circuit", "Sci-Fi • Adventure",
        "A sample series card demonstrating the local catalog layout.",
        listOf(Episode("Episode 01", ""), Episode("Episode 02", ""))
    )
)

@Composable
fun KairoApp() {
    var tab by remember { mutableStateOf("Home") }
    var selectedAnime by remember { mutableStateOf<Anime?>(null) }
    var playerUri by remember { mutableStateOf<Uri?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Crimson,
            secondary = Color(0xFFFF7185),
            background = Ink,
            surface = Panel,
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Home", "Search", "Downloads", "Library", "Settings").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item; selectedAnime = null },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Home" -> Icons.Default.Home
                                        "Search" -> Icons.Default.Search
                                        "Downloads" -> Icons.Default.Download
                                        "Library" -> Icons.Default.Favorite
                                        else -> Icons.Default.Settings
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Crimson,
                                selectedTextColor = Color.White,
                                indicatorColor = Color(0xFF42202A),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when {
                    playerUri != null -> VideoPlayerScreen(playerUri!!) { playerUri = null }
                    selectedAnime != null -> AnimeDetailsScreen(
                        anime = selectedAnime!!,
                        onBack = { selectedAnime = null },
                        onPlayLocal = { playerUri = it }
                    )
                    else -> when (tab) {
                        "Home" -> HomeScreen(onAnime = { selectedAnime = it })
                        "Search" -> SearchScreen(onAnime = { selectedAnime = it })
                        "Downloads" -> DownloadsScreen(onPlay = { playerUri = it })
                        "Library" -> LibraryScreen(onAnime = { selectedAnime = it })
                        else -> SettingsScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        if (subtitle != null) Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun AnimeCard(anime: Anime, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .background(Panel, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(16.dp)
    ) {
        Box(
            Modifier.fillMaxWidth().height(112.dp)
                .background(Color(0xFF35131D), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.PlayCircle, null, tint = Color(0xFFFF8292), modifier = Modifier.size(46.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(anime.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(anime.genre, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun HomeScreen(onAnime: (Anime) -> Unit) {
    LazyColumn {
        item {
            Header("KAIRO", "Your anime library, all in one place")
            Text(
                "FEATURED",
                color = Crimson,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )
            Box(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(155.dp)
                    .background(Color(0xFF35131D), RoundedCornerShape(18.dp)).padding(18.dp),
                contentAlignment = Alignment.BottomStart
            ) {
                Column {
                    Text("DISCOVER YOUR NEXT SERIES", color = Color(0xFFFFA4B1), fontSize = 11.sp)
                    Text("Anime starts here.", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            Header("Popular picks", "Sample catalog — connect a licensed provider for live titles")
        }
        items(catalog) { anime -> AnimeCard(anime) { onAnime(anime) } }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
fun SearchScreen(onAnime: (Anime) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = catalog.filter { it.title.contains(query, true) || it.genre.contains(query, true) }
    Column {
        Header("Search", "Find a series in your catalog")
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Search anime...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Crimson, unfocusedBorderColor = Muted,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )
        LazyColumn { items(results) { AnimeCard(it) { onAnime(it) } } }
    }
}

@Composable
fun AnimeDetailsScreen(anime: Anime, onBack: () -> Unit, onPlayLocal: (Uri) -> Unit) {
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            try { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (_: Exception) {}
            onPlayLocal(it)
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text(anime.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Text(anime.genre, color = Muted, modifier = Modifier.padding(horizontal = 20.dp))
        Text(anime.description, color = Muted, modifier = Modifier.padding(20.dp))
        Text("EPISODES", color = Crimson, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
        LazyColumn {
            items(anime.episodes) { episode ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
                        .background(Panel, RoundedCornerShape(12.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(episode.title, fontWeight = FontWeight.SemiBold)
                        Text("Choose a local file or download from Downloads", color = Muted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { picker.launch(arrayOf("video/*")) }) {
                        Icon(Icons.Default.PlayArrow, "Play local episode", tint = Crimson)
                    }
                }
            }
        }
        Button(
            onClick = { picker.launch(arrayOf("video/*")) },
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Crimson)
        ) { Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(8.dp)); Text("Play a local episode") }
    }
}

data class DownloadEntry(val id: Long, val title: String, val status: Int, val downloaded: Long, val total: Long)

@Composable
fun DownloadsScreen(onPlay: (Uri) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val prefs = remember { context.getSharedPreferences("kairo_downloads", Context.MODE_PRIVATE) }

    fun entries(): List<DownloadEntry> {
        val ids = prefs.getString("ids", "")!!.split(",").mapNotNull { it.toLongOrNull() }
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return ids.mapNotNull { id ->
            val cursor = manager.query(DownloadManager.Query().setFilterById(id)) ?: return@mapNotNull null
            cursor.use {
                if (!it.moveToFirst()) return@mapNotNull null
                DownloadEntry(
                    id, prefs.getString("title_$id", "Episode") ?: "Episode",
                    it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                    it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                    it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                )
            }
        }.reversed()
    }

    val downloads = remember(refresh) { entries() }

    Column(Modifier.fillMaxSize()) {
        Header("Downloads", "Save authorized episodes for offline viewing")
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                .background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Text("ADD EPISODE DOWNLOAD", color = Crimson, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            OutlinedTextField(
                value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Episode name") }, singleLine = true
            )
            OutlinedTextField(
                value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Direct HTTPS video URL") }, singleLine = true
            )
            Button(
                onClick = {
                    val parsed = runCatching { Uri.parse(url.trim()) }.getOrNull()
                    if (title.isBlank() || parsed?.scheme != "https" || parsed.host.isNullOrBlank()) {
                        Toast.makeText(context, "Enter a name and a valid HTTPS video URL.", Toast.LENGTH_LONG).show()
                    } else {
                        try {
                            val safeName = title.trim().replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
                            val request = DownloadManager.Request(parsed)
                                .setTitle(title.trim())
                                .setDescription("Kairo offline episode")
                                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                .setAllowedOverMetered(true)
                                .setAllowedOverRoaming(false)
                                .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_MOVIES, "$safeName.mp4")
                            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            val id = manager.enqueue(request)
                            val old = prefs.getString("ids", "")!!.split(",").filter { it.isNotBlank() }
                            prefs.edit().putString("ids", (old + id.toString()).joinToString(","))
                                .putString("title_$id", title.trim()).apply()
                            title = ""; url = ""; refresh++
                            Toast.makeText(context, "Download queued.", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, "Could not start download: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Crimson)
            ) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("Download episode") }
            Text("Only use direct links supplied by a service that authorizes downloading. DRM-protected streams and segmented streaming manifests are not direct video files.", color = Muted, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("YOUR DOWNLOADS", color = Crimson, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { refresh++ }) { Icon(Icons.Default.Refresh, null); Text("Refresh") }
        }
        if (downloads.isEmpty()) {
            Text("No downloads yet.", color = Muted, modifier = Modifier.padding(20.dp))
        } else {
            LazyColumn {
                items(downloads) { item ->
                    val percent = if (item.total > 0) (item.downloaded * 100 / item.total).toInt() else 0
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
                            .background(Panel, RoundedCornerShape(12.dp)).padding(14.dp)
                    ) {
                        Text(item.title, fontWeight = FontWeight.SemiBold)
                        val statusText = when (item.status) {
                            DownloadManager.STATUS_SUCCESSFUL -> "Completed"
                            DownloadManager.STATUS_FAILED -> "Failed"
                            DownloadManager.STATUS_PAUSED -> "Paused"
                            DownloadManager.STATUS_RUNNING -> "Downloading — $percent%"
                            DownloadManager.STATUS_PENDING -> "Queued"
                            else -> "Status unavailable"
                        }
                        Text(statusText, color = Muted, fontSize = 12.sp)
                        if (item.status == DownloadManager.STATUS_RUNNING || item.status == DownloadManager.STATUS_PENDING) {
                            LinearProgressIndicator(
                                progress = { if (item.total > 0) item.downloaded.toFloat() / item.total else 0f },
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                color = Crimson
                            )
                        }
                        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                            if (item.status == DownloadManager.STATUS_SUCCESSFUL) {
                                TextButton(onClick = {
                                    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                    val uri = manager.getUriForDownloadedFile(item.id)
                                    if (uri != null) onPlay(uri)
                                    else Toast.makeText(context, "Downloaded file not found.", Toast.LENGTH_SHORT).show()
                                }) { Icon(Icons.Default.PlayArrow, null); Text("Play") }
                            }
                            TextButton(onClick = {
                                (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(item.id)
                                prefs.edit().putString("ids", prefs.getString("ids", "")!!.split(",").filter { it != item.id.toString() }.joinToString(",")).apply()
                                refresh++
                            }) { Icon(Icons.Default.Delete, null); Text("Remove") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LibraryScreen(onAnime: (Anime) -> Unit) {
    LazyColumn {
        item { Header("My Library", "Your saved series") }
        item {
            Text("Sample library", color = Muted, modifier = Modifier.padding(horizontal = 20.dp))
        }
        items(catalog.take(2)) { AnimeCard(it) { onAnime(it) } }
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize()) {
        Header("Settings", "Customize your Kairo experience")
        listOf(
            "Appearance" to "Dark crimson / black",
            "Downloads" to "Stored in app-specific Movies folder",
            "Playback" to "Local video playback",
            "Content sources" to "Connect authorized catalogs and servers",
            "Version" to "1.0.0"
        ).forEach { (title, value) ->
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp)
                .background(Panel, RoundedCornerShape(12.dp)).padding(16.dp)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(value, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun VideoPlayerScreen(uri: Uri, onBack: () -> Unit) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
            Text("Now playing", color = Color.White, fontWeight = FontWeight.Bold)
        }
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply { this.player = player; useController = true }
            },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
    }
}
