# Kairo — Android starter

Kairo is a native Android starter written in Kotlin and Jetpack Compose, with a dark crimson/black interface.

## Included
- Home, Search, Downloads, Library and Settings tabs
- Sample catalog and details screens
- Direct HTTPS video-file downloads from sources that explicitly authorize downloading
- Android DownloadManager progress/status, play and remove actions
- Media3 ExoPlayer playback
- Local video picker

## Build an APK without a PC (GitHub Actions)
This project includes `.github/workflows/build-apk.yml`.

1. On your phone, sign in to GitHub and create a new repository.
2. Upload the CONTENTS of this source ZIP to the repository (not the ZIP itself).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Run **Build Kairo debug APK** using **Run workflow** (or push to the `main` branch).
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, scroll to **Artifacts**, and download `Kairo-debug-apk`.
7. Extract that artifact ZIP on your phone and tap `app-debug.apk` to install it. If Android asks, allow your browser or file manager to install unknown apps for this install.

**The APK is NOT included in this source ZIP.** GitHub Actions compiles it in the cloud.

## Requirements
- JDK 17
- Android SDK 35
- Gradle 8.9 (the workflow installs this automatically)

## Download behavior and limitations
The Downloads screen accepts direct HTTPS URLs to video files from a source that explicitly authorizes downloading. Files are saved in the app-specific Movies folder and managed by Android DownloadManager. This starter does not scrape websites, bypass DRM, or download protected streams. HLS/DASH manifests and authenticated provider downloads need a provider-specific authorized integration.

The catalog currently contains sample data. Replace it with a licensed catalog API or your own authorized server. Favorites and watch history are UI placeholders. Subtitle selection, provider authentication and automated tests are not implemented yet.
